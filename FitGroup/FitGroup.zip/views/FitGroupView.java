package FitGroup.views;

import javax.swing.*;

abstract public class FitGroupView {
	JFrame mainFrame;

    public JFrame getFrame () {
        return mainFrame;
    }
}